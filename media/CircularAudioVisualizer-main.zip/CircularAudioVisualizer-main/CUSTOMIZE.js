//Colors: [R,G,B]

//main color
let primary=[0,136,255]
//gradient color
let secondary=[0,255,136]

//background
let bg=[0,0,0]
